#include <iostream>
using namespace std;

int main() {
    cout << "Hola Mundo!" << endl;
    return 0;
}
