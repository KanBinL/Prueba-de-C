#include <iostream>
using namespace std;

/**
 * Pido el nombre y lo muestro por pantalla
*/

int main(){
    string nombre;
    cout << "Introduce tu nombre :";
    cin >> nombre;
    cout << "Este es el nombre : "<< nombre;
    return 0;
}