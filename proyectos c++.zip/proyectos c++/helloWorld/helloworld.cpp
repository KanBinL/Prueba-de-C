#include <iostream>
using namespace std;

int main(){
    const string helloWorld = "Hello world";
    cout << "Frase Hello World : " <<  helloWorld << '\n';
    cout << "Frase Hello World : " << '\t' << helloWorld << '\n';
    return 0;
}